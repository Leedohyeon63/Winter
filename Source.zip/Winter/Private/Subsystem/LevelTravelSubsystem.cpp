#include "Subsystem/LevelTravelSubsystem.h"

#include "Actor/LevelPortal.h"
#include "GameFramework/Controller.h"
#include "Kismet/GameplayStatics.h"
#include "Misc/PackageName.h"
#include "PlayerCharacter.h"

bool ULevelTravelSubsystem::TravelToLevel(
	APlayerCharacter* Player,
	const TSoftObjectPtr<UWorld>& TargetLevel,
	FName TargetPortalId)
{
	if (!IsValid(Player) || TargetLevel.IsNull())
	{
		return false;
	}

	const FString TargetPackageName = TargetLevel.ToSoftObjectPath().GetLongPackageName();
	if (!FPackageName::IsValidLongPackageName(TargetPackageName))
	{
		UE_LOG(LogTemp, Warning, TEXT("[LevelTravel] ��ȿ���� ���� ��� ���� ���: %s"), *TargetPackageName);
		return false;
	}

	// [���� �̵� �߰�] OpenLevel�� ���� World�� Pawn�� �ı��ϱ� ���� ���� ���¸� GameInstance�� �����Ѵ�.
	SavedPlayerState = Player->CaptureTravelState();
	if (!SavedPlayerState.bIsValid)
	{
		return false;
	}

	PendingTargetPortalId = TargetPortalId;
	bHasPendingTravel = true;

	UGameplayStatics::OpenLevel(Player, FName(*TargetPackageName), true);
	return true;
}

void ULevelTravelSubsystem::RestorePlayerAfterTravel(APlayerCharacter* Player)
{
	if (!bHasPendingTravel || !IsValid(Player) || !SavedPlayerState.bIsValid)
	{
		return;
	}

	// [���� �̵� �߰�] �������̳� �ߺ� ������ ���� ���� ���� ��� �÷��׸� ������.
	bHasPendingTravel = false;

	Player->RestoreTravelState(SavedPlayerState);

	FTransform DestinationTransform;
	if (FindDestinationTransform(Player->GetWorld(), PendingTargetPortalId, DestinationTransform))
	{
		Player->SetActorTransform(DestinationTransform, false, nullptr, ETeleportType::TeleportPhysics);

		if (AController* PlayerController = Player->GetController())
		{
			PlayerController->SetControlRotation(DestinationTransform.Rotator());
		}
	}
	else if (!PendingTargetPortalId.IsNone())
	{
		UE_LOG(LogTemp, Warning, TEXT("[LevelTravel] ��� ��Ż ID�� ã�� ���߽��ϴ�: %s"), *PendingTargetPortalId.ToString());
	}

	PendingTargetPortalId = NAME_None;
	SavedPlayerState = FPlayerTravelState();
}

bool ULevelTravelSubsystem::FindDestinationTransform(
	UWorld* World,
	FName PortalId,
	FTransform& OutTransform) const
{
	if (!World || PortalId.IsNone())
	{
		return false;
	}

	TArray<AActor*> FoundPortals;
	UGameplayStatics::GetAllActorsOfClass(World, ALevelPortal::StaticClass(), FoundPortals);

	for (AActor* FoundActor : FoundPortals)
	{
		const ALevelPortal* Portal = Cast<ALevelPortal>(FoundActor);
		if (Portal && Portal->GetPortalId() == PortalId)
		{
			OutTransform = Portal->GetArrivalTransform();
			return true;
		}
	}

	return false;
}
