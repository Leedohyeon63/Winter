// Fill out your copyright notice in the Description page of Project Settings.


#include "Attribute/PlayerStatAttributeSet.h"
#include "GameplayEffectExtension.h"

UPlayerStatAttributeSet::UPlayerStatAttributeSet()
{
	InitHealth(100.f);
	InitMaxHealth(100.f);
	InitStamina(50.f);
	InitMaxStamina(50.f);
	InitMentality(100.f);
	InitMaxMentality(100.f);
}

void UPlayerStatAttributeSet::PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data)
{
	Super::PostGameplayEffectExecute(Data);

	if (Data.EvaluatedData.Attribute == GetHealthAttribute())
	{
		SetHealth(FMath::Clamp(GetHealth(), 0.0f, GetMaxHealth()));

		if (GetHealth() <= 0.0f)
		{
			UE_LOG(LogTemp, Log, TEXT("���"));
		}
	}

	else if (Data.EvaluatedData.Attribute == GetStaminaAttribute())
	{
		SetStamina(FMath::Clamp(GetStamina(), 0.0f, GetMaxStamina()));

		if (GetStamina() <= 0.0f)
		{
			//�ٸ����� �ش� �ڵ尡 �־�� �� �� ���� ���׹̳� 0�϶�
		}
	}

	else if (Data.EvaluatedData.Attribute == GetMentalityAttribute())
	{
		SetMentality(FMath::Clamp(GetMentality(), 0.0f, GetMaxMentality()));

		if (GetMentality() <= 20.0f)
		{
			//�̰͵� �ٸ����� ��� �� �� ����
		}
	}
}
