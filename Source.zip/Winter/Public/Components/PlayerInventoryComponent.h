#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Struct/InventoryTypeStruct.h"
#include "PlayerInventoryComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnInventoryChangedSignature);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnCarryWeightChangedSignature, float, CurrentWeight, float, MaxWeight);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnInventoryCapacityChangedSignature, int32, UsedSlots, int32, MaxSlots);

/**
 * �̱��÷��̿� �÷��̾� �κ��丮.
 * �迭�� �� ���Ұ� UI�� �� �����̸� ���� �������� MaxStackSize��ŭ ���δ�.
 */
UCLASS(ClassGroup = (Inventory), meta = (BlueprintSpawnableComponent))
class WINTER_API UPlayerInventoryComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UPlayerInventoryComponent();

	UPROPERTY(BlueprintAssignable, Category = "Inventory|Events")
	FOnInventoryChangedSignature OnInventoryChanged;

	UPROPERTY(BlueprintAssignable, Category = "Inventory|Events")
	FOnCarryWeightChangedSignature OnCarryWeightChanged;

	UPROPERTY(BlueprintAssignable, Category = "Inventory|Events")
	FOnInventoryCapacityChangedSignature OnCapacityChanged;

	/** ������ ������ �߰��ϰ� ���� �߰��� ������ ��ȯ�Ѵ�. */
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	int32 AddItem(UItemDefinitionDataAsset* Item, int32 Quantity = 1);

	/** ��û ������ ���� ������ �� ���� ���� �����Ѵ�. */
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	bool RemoveItem(UItemDefinitionDataAsset* Item, int32 Quantity = 1);

	UFUNCTION(BlueprintPure, Category = "Inventory")
	bool CanAddItem(UItemDefinitionDataAsset* Item, int32 Quantity = 1) const;

	UFUNCTION(BlueprintPure, Category = "Inventory")
	int32 GetAddableQuantity(UItemDefinitionDataAsset* Item, int32 RequestedQuantity) const;

	UFUNCTION(BlueprintPure, Category = "Inventory")
	int32 GetItemQuantity(UItemDefinitionDataAsset* Item) const;

	UFUNCTION(BlueprintPure, Category = "Inventory")
	TArray<FInventoryStack> GetItems() const { return Items; }

	UFUNCTION(BlueprintPure, Category = "Inventory|Capacity")
	int32 GetUsedSlotCount() const { return Items.Num(); }

	UFUNCTION(BlueprintPure, Category = "Inventory|Capacity")
	int32 GetSlotCapacity() const;

	UFUNCTION(BlueprintPure, Category = "Inventory|Weight")
	float GetInventoryWeight() const;

	UFUNCTION(BlueprintPure, Category = "Inventory|Weight")
	float GetEquipmentWeight() const;

	UFUNCTION(BlueprintPure, Category = "Inventory|Weight")
	float GetTotalCarriedWeight() const;

	UFUNCTION(BlueprintPure, Category = "Inventory|Weight")
	float GetMaxCarryWeight() const;

	/** �κ��丮�� �ִ� ������ �� ���� ������ ��� ���Կ� �����Ѵ�. */
	UFUNCTION(BlueprintCallable, Category = "Inventory|Equipment")
	bool EquipItem(UItemDefinitionDataAsset* Item);

	/** ��� �κ��丮�� �ǵ��� �ڿ��� ����/���� ������ ������ ���� �����Ѵ�. */
	UFUNCTION(BlueprintCallable, Category = "Inventory|Equipment")
	bool UnequipItem(EEquipmentSlot Slot);

	UFUNCTION(BlueprintPure, Category = "Inventory|Equipment")
	UItemDefinitionDataAsset* GetEquippedItem(EEquipmentSlot Slot) const;

	UFUNCTION(BlueprintPure, Category = "Inventory|Equipment")
	TMap<EEquipmentSlot, UItemDefinitionDataAsset*> GetEquippedItems() const;

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Inventory|Capacity", meta = (ClampMin = "0"))
	int32 BaseSlotCapacity = 4;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Inventory|Capacity", meta = (ClampMin = "0.0"))
	float BaseMaxCarryWeight = 10.0f;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "Inventory")
	TArray<FInventoryStack> Items;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "Inventory|Equipment")
	TMap<EEquipmentSlot, TObjectPtr<UItemDefinitionDataAsset>> EquippedItems;

private:
	void AddItemUnchecked(UItemDefinitionDataAsset* Item, int32 Quantity);
	bool RemoveItemInternal(UItemDefinitionDataAsset* Item, int32 Quantity);
	bool IsCurrentStateWithinCapacity() const;
	void BroadcastStateChanged();
};